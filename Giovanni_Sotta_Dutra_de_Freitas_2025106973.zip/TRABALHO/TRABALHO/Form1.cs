namespace TRABALHO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        int contador = 0;
        private void textoL2()
        {
            label2.Text = "Contador: " + (obterContador()).ToString();
        }
        private int obterContador()
        {
            return contador;
        }
        private void incrementarContador()
        {
            contador++;
        }
        private void zerarContador()
        {
            contador = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {

            switch (obterContador())
            {
                case 6:
                    {
                        incrementarContador();
                        label1.Text = "Faltam mais 3 cliques";
                        break;
                    }
                case 7:
                    {
                        incrementarContador();
                        label1.Text = "Agora faltam 2 cliques";
                        break;
                    }
                case 8:
                    {
                        incrementarContador();
                        label1.Text = "Mais 1 apenas";
                        break;
                    }
                case 9:
                    {
                        incrementarContador();
                        label1.Text = "Acabou !";
                        break;
                    }
                case < 7:
                    {
                        incrementarContador();
                        break;
                    }
                default:
                    {
                        return;
                    }

            }
            textoL2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            zerarContador();
            label1.Text = "Come�o";
            textoL2();
        }

    }
}
